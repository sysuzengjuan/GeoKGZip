<template>
  <div class="VueToNuxtLogo">
    <img src="/logo.PNG" width="100" height="40"/>
  </div>
</template>

<style>
.VueToNuxtLogo {
  display: inline-block;
  overflow: hidden;
  height: 40px;
  width: 120px;
}
</style>
